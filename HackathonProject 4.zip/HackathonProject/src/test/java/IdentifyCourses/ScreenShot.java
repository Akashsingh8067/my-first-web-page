package IdentifyCourses;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.PageFactory;

public class ScreenShot {
	
	WebDriver driver;
	public ScreenShot(WebDriver driver)
	{
		this.driver = driver;	
	}
	
	public void takeScreenshot(String screenshotName) throws IOException {
	    TakesScreenshot ts = (TakesScreenshot) driver;
	    File s = ts.getScreenshotAs(OutputType.FILE);
	    File trg = new File("C:\\Users\\2317305\\MinorProject\\HackathonProject\\src\\test\\resources\\Screenshots\\" + screenshotName + ".png");
	    FileHandler.copy(s, trg);
	}


}
