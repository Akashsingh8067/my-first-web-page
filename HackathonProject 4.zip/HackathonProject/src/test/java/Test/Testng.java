package Test;

import org.testng.annotations.Test;

import com.beust.jcommander.Parameter;

import IdentifyCourses.HomePage;
import IdentifyCourses.Institution;
import IdentifyCourses.ScreenShot;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;


public class Testng {
	WebDriver driver;
	HomePage ho;
	Institution inst;
	ScreenShot ss;
    @BeforeClass
    @Parameters({"browser"})
	void URL(String br) {
    	if(br.equals("chrome"))
    	{	
		driver = new ChromeDriver();
         }
    	else if(br.equals("edge"))
    	{
    	 driver = new EdgeDriver();	
    	}
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://www.coursera.org/");
		driver.manage().window().maximize();
		ss = new ScreenShot(driver);
	}
    
//step1 --------Search for web development courses for Beginners level & English Language
	@Test(priority=1)
	void HomePagesearch() throws InterruptedException, IOException
	{
		ho = new HomePage(driver);
		ho.searchbutton();//-------clicking on search button and write web development course
		ho.clicksearch();//-------clicking and searching above course
		ss.takeScreenshot("CourseSelect");
		ho.languageselect();//------ selecting the language 
		ho.levelselect();//-------selecting the level
	}
	
//Step 1 ----------extract the course names,details & rating for first 2 courses	
	@Test(priority=2)
	void searchResults() throws InterruptedException {	
		ho.CourseTitle();//---------first two course title 
		ho.CourseRating();//---------first two course rating
		ho.courseDetail();//---------first two course details 
	}

	@Test(priority=3)
	void deSelect()//--------disselecting language and levels 
	{
		ho.languageselect();
		ho.levelselect();
	}
//STep 2 --------- Extract all the languages and different levels with its total count & display them	
	@Test(priority =4)
	void languagesandLevels() throws InterruptedException {

		ho.Alllanguages();//-----printing all languages 
		Thread.sleep(3000);
		ho.Alllevels();//--------printing all levels 
		driver.navigate().to("https://www.coursera.org/");//-----navigating back to home page 
		Thread.sleep(3000);

	}
	
	
	@Test(priority =5)
	void Navigate() throws InterruptedException, IOException
	{
		inst = new Institution(driver);
        inst.ClickEnterprise();
        inst.campusclick();
        Thread.sleep(2000);
        inst.locateform();
        ss.takeScreenshot("form");
	}
	@Test(priority =6,dataProvider= "formdetails")
	
	void form(String f_name,String l_name,String email,String phone,String institutiontype, String institutionname,String Jobrole,String department,String whichd,String learn,String country,String state) throws InterruptedException
	{
	   	inst.formdetails(f_name, l_name, email, phone, institutiontype, institutionname, Jobrole, department, whichd,learn,country,state);
	   	inst.submitForm();
	   	Thread.sleep(3000);
	 	inst.errormsg();
	    Thread.sleep(2000); 	
	}
	
	@AfterClass
	void close()
	{
		driver.quit();
	}
	
	@DataProvider(name ="formdetails")
	 String [][] formdetails()
	 {
		String data[][] = {
				{"Akash","kumar",
				"aaa123s@gmail.com","8989788900",
				"2 Year College","Ajki",
				"Vice-President/Vice-Provost","Career Services",
				"Meet with Coursera Sales Team","5-25","India","Gujarat"}

			};
		return data;
		
	 }
	
	
         
}
