package TruTime;

import java.io.IOException;
import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Locale;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.*;



public class TestngClass {
    WebDriver driver;
    BaseClass ba;
	BeCognizant be ;
	OneCognizant oncog ;
	TruTime tru ;
	LocalDate currentDate = LocalDate.now();
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("EEE, d MMM", Locale.ENGLISH);
	
	//Navigating the website 
	@BeforeClass

	void Navigate()
	  {
	    driver = new ChromeDriver();
		driver.manage().window().maximize();
	    driver.get(" https://be.cognizant.com");
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		ba = new BaseClass(driver);
	    be = new BeCognizant(driver);
	    oncog = new OneCognizant(driver); 
	    tru = new TruTime(driver);
	  }
	  
     //Step 1 and 2  ------Displaying user info and Clicking on One Cognizant Application.
	 @Test(priority =1)
	 void becognizant() throws IOException, InterruptedException 
     {   
		 ba.takeScreenshot("Becognizant");
    	 be.userinfo();
    	 ba.takeScreenshot("User_Info");
    	 Thread.sleep(3000);
		 be.buttonclick();
	}
	 
     //Step 3  Switching window to point on "one cognizant page" 
	 @Test(priority =2)
	 void oneCognizant() throws IOException, InterruptedException
	 {
		 
		 oncog.switchWindow();
		 Thread.sleep(3000);
		 ba.takeScreenshot("One_Cognizant");
		 String act_title = driver.getTitle();
		 String exp_title = "OneCognizant";
		 Assert.assertEquals( act_title,exp_title,"The title is not correct");
		 
	 }
	 
     //Step -3 ---Search Tru Time in Search bar and click on Tru Time application from search results.
	 @Test(priority =3)
	 void Tru_Time_searchandClick() throws IOException, InterruptedException
	 {   
		 
		 oncog.Tru_Time_search();
		 oncog.tru_button_click();
		 Thread.sleep(3000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0, 500)");
		 ba.takeScreenshot("Tru_time");
	 }
	 
     //Step4 ---------Get current week details from Tru Time and compare it with system calendar.---------
	 @Test(priority = 5)
	 void currentweek() 
	 {
		///----tru time --------//////
		 ArrayList<String> tru_week = tru.Tru_Time_Week_det();
		
		///------local week ----------////
		 LocalDate currentDate = LocalDate.now();
	        ArrayList<String> Calendar_Week = new ArrayList<String>();
	        for (int i = 0; i <= 6; i++) {
	            LocalDate weekDay = currentDate.minusDays(currentDate.getDayOfWeek().getValue() - i);
	            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("EEE, dd MMM", Locale.ENGLISH);
	            String formattedDate = weekDay.format(formatter);
	            Calendar_Week.add(formattedDate);
	        }
	        
	        System.out.println("Calender Week: ");
	        for(String wek:Calendar_Week) {
	        	System.out.println(wek);
	        }
	        
	       Boolean bol = tru_week.containsAll(Calendar_Week);
	       Assert.assertTrue(bol);

	   }
	 
     //Step5----Validate current date is visible in Tru Time application.
	 @Test(priority = 6)
	 void current_date() 
	 {
		 //Tru time current date
		 Boolean result = tru.currentdate();
		 //system date 		 
	     Assert.assertTrue(result, "Element is not visible");
	 }
	 
    //Step----6 Visibility of current month and Year in tru time 
	@Test(priority =7)
	void current_monthYear()
	{
	
        Boolean Year = tru.c_Year();
        Boolean month = tru.c_month();
     // Validate the current month and year are visible
        Assert.assertTrue(month, "Current month is not visible");
        Assert.assertTrue(Year,"Current year is not visible");
    }
	
    // Step-7---Validate backdated TopUp date is displayed correctly or not (with 15 days backdated date).
	@Test(priority =8)
	void backdate()
	{
		String topupDate =tru.backdate();
		System.out.println("The Backdate is :" + topupDate);
		LocalDate backdatedTopUpDate = currentDate.minusDays(15);
        String formattedBackdatedTopUpDate = backdatedTopUpDate.format(formatter);
        Assert.assertEquals(formattedBackdatedTopUpDate, topupDate, "The backdated TopUp date is not displayed correctly.");
    }
	
    //Step8----Validate all the legends displayed in Tru Time.
	@Test(priority =9)
	void legends()
	{
		boolean legend =tru.legends();
		Assert.assertTrue(legend);
	}
	
   // -----closing the browser 	
   @AfterClass
   void close()
   {
	  driver.quit();
   }
 }

