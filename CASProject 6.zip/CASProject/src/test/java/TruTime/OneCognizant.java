package TruTime;

import java.util.ArrayList;
import java.util.Set;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class OneCognizant extends BaseClass{

	public OneCognizant(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
	//locators 
	@FindBy(xpath ="//input[@id=\"oneC_searchAutoComplete\"]")
	WebElement search;
	 
	@FindBy(xpath ="//*[@id=\"newSearchAppsLST\"]/div/div/div[2]")
	WebElement buttonclick ;
	
	//action methods
	public void switchWindow()
	{
		Set<String> windows =driver.getWindowHandles();
		 ArrayList<String> windowtabs = new ArrayList<String>(windows);
		 driver.switchTo().window(windowtabs.get(1));
	}
	public void Tru_Time_search()
	{
		
		search.sendKeys("TruTime");
	}
	public void tru_button_click()
	{
	   buttonclick.click();
	 
	}
	
}
