package TruTime;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;

public class BeCognizant extends BaseClass {
	
	BaseClass ba;
    public BeCognizant(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	//locators
    @FindBy(xpath="//button[@id='O365_MainLink_Me']") 
	WebElement button_userinfo;
    
	@FindBy(xpath="//div[@class='mectrl_accountDetails']/div[1]")
	WebElement txt_username;
	
	@FindBy(xpath="//div[@class='mectrl_accountDetails']/div[2]")
	WebElement txt_useremail;
    
	@FindBy(xpath="//div[@title=\"OneCognizant\"]")
	WebElement one_cog_button;
	
	//Action Methods 
	public void userinfo() 
	{    
		try
		{
			WebElement userIcon = button_userinfo;
			Actions actions = new Actions(driver);
			actions.moveToElement(userIcon).click().build().perform();
			Thread.sleep(3000);
			userIcon.click();
			Thread.sleep(3000);
			System.out.println("USER-INFORMATION");
		System.out.println(txt_username.getText());
		System.out.println(txt_useremail.getText());
		}
		catch(Exception e){
			System.out.println(e);
		}
	}
	
	public void buttonclick()
	{
	  one_cog_button.click();	
	}
}
