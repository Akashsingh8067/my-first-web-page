package TruTime;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class TruTime extends BaseClass {

	public TruTime(WebDriver driver) {
		super(driver);
	}

	// locators
	@FindBy(xpath = "//iframe[@id='appFrame']")
	WebElement switchframe;
	@FindBy(xpath = "//div[@class='dayHeadr active ng-binding ng-scope']")
	WebElement cur_data;
	@FindBy(xpath = "//span[@class=\"ui-datepicker-month\"]")
	WebElement month;
	@FindBy(xpath = "//span[@class=\"ui-datepicker-year\"]")
	WebElement year;
	@FindBy(css = "span.topupavailablefromDate")
	WebElement back;
	@FindBy(id = "legendListID")
	WebElement legend;

	// agent methods
	public void Switchframe() {
		driver.switchTo().frame(switchframe);
	}

	public Boolean currentdate() {
		Boolean result =  cur_data.isDisplayed();
		System.out.println("The current date is : "+cur_data.getText());
		return result;
	}

	public Boolean c_month() {
		Boolean result_month = month.isDisplayed();
		System.out.println("The current month is: "+month.getText());
		return result_month;
	}

	public Boolean c_Year() {
		Boolean result_year = year.isDisplayed();
		System.out.println("The current year is: "+year.getText());
		return result_year;
	}

	public String backdate() {
		return back.getText();
	}

	public boolean legends() {
		System.out.println("The legends are : "+legend.getText());
		return legend.isDisplayed();
	}

	public ArrayList<String> Tru_Time_Week_det() {
		Switchframe();// switching to frame
		
		ArrayList<WebElement> tru_time_week = (ArrayList<WebElement>) driver
				.findElements(By.xpath("//div[@class='dayHeadr ng-binding ng-scope']"));
		WebElement tru_time_cur_date = driver
				.findElement(By.xpath("//div[@class='dayHeadr active ng-binding ng-scope']"));
		tru_time_week.add(tru_time_cur_date);
		ArrayList<String> trutime_week = new ArrayList<String>();
		for (WebElement y : tru_time_week) {
			trutime_week.add(y.getText());
		}
		System.out.println("True Time week:");
		for (WebElement x : tru_time_week) {
			System.out.println(x.getText());
		}
		return trutime_week;
	}

}
